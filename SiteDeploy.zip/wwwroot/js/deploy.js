const { createApp, ref, unref, reactive, computed, onMounted, onUnmounted, nextTick, watch } = Vue;
function getNowDateTime() {
    const date = new Date();
    const year = date.getFullYear();
    // 补0工具
    const pad = (n) => n.toString().padStart(2, '0');
    const month = pad(date.getMonth() + 1);
    const day = pad(date.getDate());
    const hour = pad(date.getHours());
    const minute = pad(date.getMinutes());
    const second = pad(date.getSeconds());
    return `${year}-${month}-${day} ${hour}:${minute}:${second}`;
}

const app = createApp({
    setup() {
        const pageName = ref('site');  //user poll
        const sites = ref([]);
        const siteLoading = ref(false);
        const selectedSite = ref(null);
        const selectedApp = ref(null);
        const activeTab = ref('publish');
        const backups = ref([]);
        const isRecently = ref(false);
        const selectedBackupId = ref(null);
        const backupBeforeDeploy = ref(false);
        const backupUploadFiles = ref(true);
        const stopBeforeDeploy = ref(true);
        const startEndDeploy = ref(true);
        const backupExcludeDirectories = ref("");
        const backupExcludeExtensions = ref("");
        const publishing = ref(false);
        const rollingBack = ref(false);
        const publishButtonText = ref(translate('LogStartPub', ''));
        const collapsedNodes = ref(new Set());
        const visible = ref(false);
        const totalSiteUsers = ref(0);
        const currentSiteUsers = ref(0);
        const loadingBackUp = ref(false);
        const initialPermission = window.INITIAL_USER_PERMISSION || {};
        const initialUser = window.INITIAL_USER || '';
        const userPermission = Object.freeze(initialPermission);
        const currentSiteItem = ref(window.nodeUrls[0]);
        const currentServerUrl = window.currentUrl;

        // api.js
        const request = async (url, options = {}) => {
            const basePath = window.appBasePath || '';

            // 提取 options 中的 headers，避免污染原对象
            const customHeaders = options.headers || {};

            const response = await fetch(`${basePath}${url}`, {
                ...options,
                headers: {
                    'Content-Type': 'application/json',
                    // 优先使用调用方在 headers 里传的 site-url，如果没有则取默认的 currentSiteItem
                    'site-url': customHeaders['site-url'] || customHeaders['Site-Url'] || currentSiteItem.value.url,
                    ...customHeaders
                }
            });

            if (response.status === 401) {
                throw { status: 401, message: translate('SignalRAuthExpired') };
            }

            // 1. 优先检查 HTTP 状态码是否正常（处理 502, 500, 404 等非 2xx 的情况）
            if (!response.ok) {
                let errorMsg = `请求错误: ${response.status} ${response.statusText}`;
                try {
                    const text = await response.text();
                    if (text) errorMsg = text;
                } catch (e) {
                    // 忽略文本读取异常
                }
                throw { status: response.status, message: errorMsg };
            }

            // 2. 状态码正常（2xx）时，再处理 JSON 响应
            const contentType = response.headers.get('content-type');
            if (contentType && contentType.includes('application/json')) {
                const data = await response.json();
                if (data && data.success === false) {
                    throw new Error(data.message || `请求错误: ${response.status}`);
                }
                return data;
            }

            return response;
        };

        const authApi = {
            login: (form) => request('/api/auth/login', { method: 'POST', body: JSON.stringify(form) }),
            logout: () => { window.location.href = `${window.appBasePath}/api/auth/logout`; },
            setLanguage: (lan) => fetch(`${window.appBasePath}/api/auth/SetLanguage?culture=${lan}`),
            testConnection: (url) => request(`/api/auth/connection?url=${encodeURIComponent(url)}`)
        };

        const deployApi = {
            getSites: () => request('/api/deploy/sites'),
            getBackups: (siteName, appPath) => {
                let url = `/api/deploy/backups?siteName=${encodeURIComponent(siteName)}`;
                if (appPath) url += `&applicationPath=${encodeURIComponent(appPath)}`;
                return request(url);
            },
            rollback: (data) => request('/api/deploy/rollback', { method: 'POST', body: JSON.stringify(data) }),
            deleteBackup: (data) => request('/api/deploy/deleteBackup', { method: 'POST', body: JSON.stringify(data) }),
            downloadBackup: (data) => fetch(`${window.appBasePath}/api/deploy/downloadBackup`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(data)
            }),
            stopSite: (data) => request('/api/deploy/stopSite', { method: 'POST', body: JSON.stringify(data) }),
            startSite: (data) => request('/api/deploy/startSite', { method: 'POST', body: JSON.stringify(data) }),
            restartSite: (siteName) => request('/api/deploy/restartSite', { method: 'POST', body: JSON.stringify({ siteName }) }),
            saveBindings: (payload) => request('/api/deploy/saveBindings', { method: 'POST', body: JSON.stringify(payload) }),
            getServerIps: () => request('/api/deploy/server-ips'),
            createSite: (form) => request('/api/deploy/createSite', { method: 'POST', body: JSON.stringify(form) }),
            updateSiteBasic: (form) => request('/api/deploy/updateSiteBasic', { method: 'POST', body: JSON.stringify(form) }),
            createApp: (obj) => request('/api/deploy/createApp', { method: 'POST', body: JSON.stringify(obj) }),
            deleteSite: (siteName, appPath, siteId) => request(`/api/deploy/deleteSite?siteName=${encodeURIComponent(siteName)}&appPath=${encodeURIComponent(appPath)}&siteId=${siteId}`, { method: 'DELETE' }),
            getDirectories: (path) => request(`/api/deploy/directories?path=${encodeURIComponent(path)}`),
            renameSite: (siteName, newSiteName, siteId) => request(`/api/deploy/reNameSite?siteName=${encodeURIComponent(siteName)}&newSiteName=${encodeURIComponent(newSiteName)}&siteId=${siteId}`),

            // 应用程序池相关
            getAppPools: () => request('/api/deploy/appPools'),
            startPool: (poolName) => request(`/api/deploy/startPool?poolName=${encodeURIComponent(poolName)}`),
            stopPool: (poolName) => request(`/api/deploy/stopPool?poolName=${encodeURIComponent(poolName)}`),
            recyclePool: (poolName) => request(`/api/deploy/recycleAppPool?poolName=${encodeURIComponent(poolName)}`),
            createPool: (form) => request('/api/deploy/createPool', { method: 'POST', body: JSON.stringify(form) }),
            deletePool: (poolName) => request(`/api/deploy/deletePool?poolName=${encodeURIComponent(poolName)}`, { method: 'DELETE' }),
            renamePool: (oldName, newName) => request(`/api/deploy/renameAppPool?oldName=${encodeURIComponent(oldName)}&newName=${encodeURIComponent(newName)}`),
            savePoolSettings: (poolObj) => request('/api/deploy/saveSettings', { method: 'POST', body: JSON.stringify(poolObj) }),

            // 多服务器与日志
            getDeploySiteList: (options) => request('/api/deploy/getDeploySiteList', options),
        };

        const userApi = {
            getUsers: () => request('/api/user/users'),
            addUser: (form) => request('/api/user/addUser', { method: 'POST', body: JSON.stringify(form) }),
            updateUser: (form) => request('/api/user/updateUser', { method: 'POST', body: JSON.stringify(form) }),
            enableUser: (id, enabled) => request(`/api/user/enabled/${id}?enabled=${enabled}`),
            deleteUser: (id) => request(`/api/user/deleteUser/${id}`, { method: 'DELETE' }),
            updateUserPermission: (obj) => request('/api/user/updateUserPermission', { method: 'POST', body: JSON.stringify(obj) }),
            getLogs: (params) => request(`/api/user/userLogs?${params.toString()}`)
        };

        const form = reactive({
            username: "",
            password: ""
        });
        const loginForm = ref(null);
        const rules = {
            username: [
                { required: true, message: translate('ValidationRequireUsername'), trigger: 'blur' }
            ],
            password: [
                { required: true, message: translate('ValidationRequirePassword'), trigger: 'blur' }
            ]
        };

        const login = async () => {
            const valid = await loginForm.value.validate().catch(() => false);
            if (!valid) return;
            try {
                await authApi.login(form);
                visible.value = false;
                window.location.reload();
            } catch (error) {
                if (error.status === 401) {
                    showNotice(translate('NoticeLoginFailed'), 'error');
                }
            }
        };
        const selectedPhysicalPath = computed(() => {
            if (!selectedSite.value) return '';
            if (selectedApp.value) return selectedApp.value.physicalPath;
            return selectedSite.value.physicalPath;
        });
        const getAppId = () => {
            var appId = selectedSite.value.siteId;
            if (selectedApp.value?.path) appId = selectedApp.value?.siteId;
            return appId;
        };
        const currentAppId = computed(() => {
            if (selectedApp.value?.path) {
                return selectedApp.value?.siteId;
            }
            return selectedSite.value?.siteId;
        });
        const currentAppName = computed(() => {
            if (selectedApp.value?.path) {
                return selectedApp.value?.name;
            }
            return selectedSite.value?.name;
        });
        function trimSpecial(str) {
            // 先匹配开头不是中文、字母、数字的字符；再匹配结尾的
            return str.replace(/^[^\u4e00-\u9fa5a-zA-Z0-9]+|[^\u4e00-\u9fa5a-zA-Z0-9]+$/g, '');
        }
        const getConfig = () => {
            return JSON.parse(CookieUtil.get('sitedeployconfig') ?? '{}');
        };
        const getAppSettings = () => {
            const config = getConfig();
            const appId = getAppId();
            return config[appId] ?? {};
        };
        const formatLocalTime = (utcString) => {
            if (!utcString) return '-';

            let str = utcString.trim();

            // 如果没有 Z 或时区偏移量，强行补充 T 和 Z 标记为标准的 UTC 时间格式
            if (!str.endsWith('Z') && !str.includes('+') && str.includes('-')) {
                str = str.replace(' ', 'T') + 'Z'; // "2026-08-10 09:58:05" -> "2026-08-10T09:58:05Z"
            }

            const date = new Date(str);
            if (isNaN(date.getTime())) return utcString; // 异常容错

            const pad = (n) => String(n).padStart(2, '0');
            const year = date.getFullYear();
            const month = pad(date.getMonth() + 1);
            const day = pad(date.getDate());
            const hours = pad(date.getHours());
            const minutes = pad(date.getMinutes());
            const seconds = pad(date.getSeconds());

            return `${year}-${month}-${day} ${hours}:${minutes}:${seconds}`;
        };
        const initConfigData = () => {
            const appSetting = getAppSettings();
            var excludeFiles = setProjectExcludeFiles();
            var defaultBackupbeforedeploy = false;
            var defaultBackupUploadFiles = true;
            var defaultStopbeforedeploy = true;
            var defaultStartenddeploy = true;

            if (!getIsAspNetCoreProject()) {
                defaultBackupbeforedeploy = false;
                defaultBackupUploadFiles = false;
                defaultStopbeforedeploy = false;
                defaultStartenddeploy = false;
            }

            backupBeforeDeploy.value = appSetting.backupbeforedeploy ?? defaultBackupbeforedeploy;
            backupUploadFiles.value = appSetting.backupUploadFiles ?? defaultBackupUploadFiles;
            stopBeforeDeploy.value = appSetting.stopbeforedeploy ?? defaultStopbeforedeploy;
            startEndDeploy.value = appSetting.startenddeploy ?? defaultStartenddeploy;
            backupExcludeDirectories.value = appSetting.backupexcludedirectories ?? excludeFiles[0];
            backupExcludeExtensions.value = appSetting.backupexcludeextensions ?? excludeFiles[1];

            if (backupBeforeDeploy.value) backupUploadFiles.value = false;
            if (backupUploadFiles.value) backupBeforeDeploy.value = false;

            selectedServerSites.value = JSON.parse(appSetting.publishSiteSettings ?? "[]");
            if (selectedServerSites.value.length == 0) selectedServerSites.value = [{
                serverUrl: currentSiteItem.value?.url || '',
                site: {
                    name: currentAppName.value,
                    siteId: currentAppId.value
                }
            }];
            tempSelectedServerSites.value = JSON.parse(appSetting.publishSiteSettings ?? "[]");
            if (tempSelectedServerSites.value.length == 0) tempSelectedServerSites.value = [{
                serverUrl: currentSiteItem.value?.url || '',
                site: {
                    name: currentAppName.value,
                    siteId: currentAppId.value
                }
            }];

        };

        const handleSettings = () => {
            const config = getConfig();
            const appId = getAppId();
            config[appId] = {
                backupbeforedeploy: backupBeforeDeploy.value,
                backupUploadFiles: backupUploadFiles.value,
                stopbeforedeploy: stopBeforeDeploy.value,
                startenddeploy: startEndDeploy.value,
                backupexcludedirectories: backupExcludeDirectories.value,
                backupexcludeextensions: backupExcludeExtensions.value,
                publishSiteSettings: JSON.stringify(selectedServerSites.value)
            };
            CookieUtil.set('sitedeployconfig', JSON.stringify(config));
        };

        const changeRecently = () => {
            isRecently.value = !isRecently.value;
        };

        const treeData = computed(() => {
            const config = getConfig();
            const configKeys = new Set(Object.keys(config));
            const appId = CookieUtil.get("currentSelectSiteId");
            const siteList = Array.isArray(sites.value) ? sites.value : [];
            const siteNodes = siteList.map(site => {
                const children = (site.applications || [])
                    .map(app => ({
                        id: app.siteId,
                        label: app.path,
                        site: site,
                        app: app,
                        children: [],
                        meta: app.physicalPath,
                        show: true,
                        type: 'application'
                    }))
                    .sort((a, b) => a.label.localeCompare(b.label, 'zh-CN'));
                let show = true;
                if (isRecently.value) {
                    // 1. 父站点自己是否匹配
                    const siteMatched =
                        configKeys.has(site.siteId) ||
                        site.siteId === appId;
                    // 2. 子站点是否匹配
                    const childMatched = children.some(app =>
                        configKeys.has(app.id) ||
                        app.id === appId
                    );
                    // 父站点或者任意子站点匹配，都显示父站点
                    show = siteMatched || childMatched;
                }
                return {
                    id: site.siteId,
                    label: site.name,
                    stateClass: site.state === 'Started' ? 'status-running' : 'status-stopped',
                    site: site,
                    children: children,
                    show: show,
                    type: 'site'
                };
            }).sort((a, b) => a.label.localeCompare(b.label, 'zh-CN'));

            return [
                {
                    id: 'root_sites',
                    label: translate('TreeRootLabel'),
                    type: 'root',
                    children: siteNodes
                }
            ];
        });

        const formatDate = (dateStr) => {
            if (!dateStr) return '';
            return new Date(dateStr).toLocaleString();
        };

        const formatSize = (bytes) => {
            if (bytes === 0) return '0 B';
            const k = 1024;
            const sizes = ['B', 'KB', 'MB', 'GB'];
            const i = Math.floor(Math.log(bytes) / Math.log(k));
            return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
        };

        const showNotice = (message, type, duration = 5000) => {
            ElementPlus.ElNotification({
                message,
                type,
                position: 'bottom-right',
                duration: duration,
                customClass: 'my-notification'
            });
        };

        const hasChildren = (node) => !!(node.children && node.children.length);

        const isExpanded = (node) => {
            return collapsedNodes.value.has(node.id);
        }

        const toggleNode = (node) => {
            if (!hasChildren(node)) return;
            const next = new Set(collapsedNodes.value);
            if (next.has(node.id)) {
                next.delete(node.id);
            } else {
                next.add(node.id);
            }
            collapsedNodes.value = next;
        };

        const refreshSites = async () => {
            siteLoading.value = true;
            try {
                // 使用 Promise.all 并行加载：getSites 是必选的，getAppPools 根据 pageName 动态决定是否加载
                const [sitesData] = await Promise.all([
                    deployApi.getSites(),
                    pageName.value === 'pool' ? getAppPools() : Promise.resolve(null),
                    pageName.value === 'user' ? getUsers() : Promise.resolve(null)
                ]);

                sites.value = sitesData || [];
                if (pageName.value === 'site') await restoreSelectedNode();
                if (pageName.value === 'user') selectedUser.value = null;
                if (pageName.value === 'pool') selectedPool.value = null;
            } catch (error) {
                if (error.status === 401) {
                    visible.value = true;
                    return;
                }
                sites.value = [];
                selectedSite.value = null;
                selectedApp.value = null;
                showError(error.message);
            } finally {
                siteLoading.value = false;
                await nextTick();
                lucide.createIcons();
            }
        };

        const restoreSelectedNode = async () => {
            const appId = CookieUtil.get("currentSelectSiteId");

            if (!appId || !Array.isArray(sites.value) || sites.value.length == 0) return;
            // 找站点
            for (const site of sites.value) {
                // 先匹配站点
                if (site.siteId === appId) {
                    handleNodeClick({ type: "site", site });
                    await scrollToCurrentNode(appId);
                    return;
                }
                // 再匹配应用
                for (const app of site.applications ?? []) {
                    if (app.siteId !== appId) continue;
                    // 展开父节点
                    const expand = new Set(collapsedNodes.value);
                    expand.add(site.siteId);
                    collapsedNodes.value = expand;

                    handleNodeClick({ type: "application", site, app });

                    await scrollToCurrentNode(appId);
                    return;
                }
            }
        };
        const scrollToCurrentNode = async (appId) => {

            await nextTick();

            let el = document.getElementById(`${appId}`) ?? document.getElementById(`${appId}`);

            if (!el) return;

            el.scrollIntoView({
                behavior: "smooth",
                block: "center"
            });
        };

        const handleNodeClick = (data) => {
            pageName.value = 'site';
            if (data.type === 'root') {
                selectedSite.value = null;
                selectedApp.value = null;
                selectedBackupId.value = null;
                activeTab.value = 'publish';
                return;
            }
            if (data.type === 'site') {
                selectedSite.value = data.site;
                selectedApp.value = null;

            } else {
                selectedSite.value = data.site;
                selectedApp.value = data.app || null;
            }
            if (!selectedSite.value) {
                selectedSite.value = null;
                selectedApp.value = null;
                return;
            }
            selectedBackupId.value = null;
            activeTab.value = 'publish';

            setProjectExcludeFiles();

            loadBackups();

            CookieUtil.set('currentSelectSiteId', getAppId());

            nextTick().then(async () => {
                lucide.createIcons();
                initConfigData();
                await initConnection();
            });

        };
        const getIsAspNetCoreProject = () => {
            var isAspNetCoreProject = true;
            if (selectedSite.value) isAspNetCoreProject = selectedSite.value.isAspNetCoreProject;
            if (selectedApp.value && selectedApp.value) isAspNetCoreProject = selectedApp.value.isAspNetCoreProject;
            return isAspNetCoreProject;
        }
        const setProjectExcludeFiles = () => {
            var isAspNetCoreProject = getIsAspNetCoreProject();
            if (isAspNetCoreProject) {
                backupExcludeDirectories.value = "log;logs;upload;uploads";
                backupExcludeExtensions.value = ".log;.tmp;.bak;.pdb;.zip;.pdf";
            } else {
                backupExcludeDirectories.value = "log;logs;upload;uploads";
                backupExcludeExtensions.value = ".log;.tmp;.bak;.zip;.pdf";
            }
            return [backupExcludeDirectories.value, backupExcludeExtensions.value];
        };

        // 压缩包查看器响应式变量
        const zipDialogVisible = ref(false);
        const zipLoading = ref(false);
        const zipFileList = ref([]);
        // 打开压缩包预览弹窗
        // 读取解析 ZIP 文件结构
        const openZipPreview = async (targetFileObj) => {
            // 优先取传入的 file.raw 或第一个文件
            const targetFile = targetFileObj?.raw || fileList.value[0]?.raw;
            if (!targetFile) {
                showError(translate('NoticeSelectZip'));
                return;
            }

            zipDialogVisible.value = true;
            zipLoading.value = true;
            zipFileList.value = [];

            try {
                const zip = new JSZip();
                const zipContent = await zip.loadAsync(targetFile);

                const list = [];
                zipContent.forEach((relativePath, zipEntry) => {
                    list.push({
                        name: relativePath,
                        isDir: zipEntry.dir,
                        date: zipEntry.date ? formatDate(zipEntry.date) : '-'
                    });
                });

                // 排序：文件夹优先，同类按名称 A-Z 排序
                list.sort((a, b) => {
                    if (a.isDir !== b.isDir) return a.isDir ? -1 : 1;
                    return a.name.localeCompare(b.name, 'zh-CN');
                });

                zipFileList.value = list;
                nextTick(() => lucide.createIcons());
            } catch (error) {
                console.error('解压预览失败:', error);
                showError(translate('NoticeParseZipFailed'));
            } finally {
                zipLoading.value = false;
            }
        };

        const selectedFile = ref(null);
        const fileList = ref([]);
        const folderInputRef = ref(null);
        const onFileChange = (file, fileListObj) => {
            fileList.value = fileListObj;
            // 重新渲染弹窗内 icons
            nextTick(() => lucide.createIcons());
        };
        const handleRemoveFile = (file) => {
            fileList.value = fileList.value.filter(item => item.uid !== file.uid);
        };
        const isSingleZip = computed(() => {
            return fileList.value.length === 1 && fileList.value[0].name.toLowerCase().endsWith('.zip');
        });
        const totalSelectedSize = computed(() => {
            return fileList.value.reduce((sum, item) => sum + (item.size || 0), 0);
        });

        // 2. 点击“选择文件夹”触发隐藏 input 的点击事件
        const triggerFolderSelect = () => {
            if (folderInputRef.value) {
                folderInputRef.value.click();
            }
        };
        const onFolderSelect = (e) => {
            const files = Array.from(e.target.files);
            if (!files.length) return;

            // 转换成 Element Plus 上传列表可识别的对象结构
            const folderFiles = files.map((file, index) => ({
                // 🌟 核心修正：优先使用 webkitRelativePath 显示文件夹相对路径结构
                name: file.webkitRelativePath || file.name,
                size: file.size,
                raw: file,
                uid: Date.now() + index,
                status: 'ready'
            }));

            // 追加合并到现有文件列表中
            fileList.value = [...fileList.value, ...folderFiles];

            // 清空 input 确保允许重复选择同一个文件夹
            e.target.value = '';

            nextTick(() => lucide.createIcons());
        };
        // 递归遍历拖拽的 Entry 节点（支持无限层级文件夹解析）
        const scanFilesFromEntry = async (entry, path = '') => {
            const files = [];
            if (entry.isFile) {
                // 节点是文件：获取标准 File 对象
                const file = await new Promise((resolve) => entry.file(resolve));
                const fullPath = path + file.name;

                // 强行赋予 webkitRelativePath，保持与按钮选择文件夹结构一致（如 "Files/app.json"）
                try {
                    Object.defineProperty(file, 'webkitRelativePath', {
                        value: fullPath,
                        writable: true,
                        configurable: true
                    });
                } catch (e) {
                    file.webkitRelativePath = fullPath;
                }
                files.push(file);
            } else if (entry.isDirectory) {
                // 节点是文件夹：读取文件夹下的所有子项
                const dirReader = entry.createReader();
                const entries = await new Promise((resolve) => {
                    let result = [];
                    const read = () => {
                        dirReader.readEntries((batch) => {
                            if (!batch.length) {
                                resolve(result);
                            } else {
                                result = result.concat(batch);
                                read(); // 分批读取，防止大文件夹丢失文件
                            }
                        });
                    };
                    read();
                });

                // 递归遍历子目录
                for (const subEntry of entries) {
                    const subFiles = await scanFilesFromEntry(subEntry, `${path}${entry.name}/`);
                    files.push(...subFiles);
                }
            }
            return files;
        };

        // 处理拖拽放置事件
        // 处理拖拽放置事件
        const handleDrop = async (e) => {
            // 1. 阻止默认行为和冒泡
            e.preventDefault();
            e.stopPropagation();

            const rawItems = e.dataTransfer?.items;
            if (!rawItems || !rawItems.length) return;

            // 🌟 关键步骤：必须【同步】提取所有 entry / file 对象！
            // 绝对不能在遍历 rawItems 的过程中直接 await，否则 rawItems 在第一次 await 后会被浏览器清空
            const entriesToScan = [];
            for (let i = 0; i < rawItems.length; i++) {
                const item = rawItems[i];
                if (item.kind === 'file') {
                    const entry = item.webkitGetAsEntry ? item.webkitGetAsEntry() : null;
                    if (entry) {
                        entriesToScan.push({ type: 'entry', entry });
                    } else {
                        const file = item.getAsFile();
                        if (file) entriesToScan.push({ type: 'file', file });
                    }
                }
            }

            publishing.value = true;
            try {
                const allScannedFiles = [];

                // 2. 现在可以安全地异步扫描前面提出来的普通 JS 数组了
                for (const target of entriesToScan) {
                    if (target.type === 'entry') {
                        const files = await scanFilesFromEntry(target.entry);
                        allScannedFiles.push(...files);
                    } else if (target.type === 'file') {
                        allScannedFiles.push(target.file);
                    }
                }

                if (allScannedFiles.length > 0) {
                    // 3. 格式化为与 Element Plus 文件列表结构一致的对象
                    const newFileItems = allScannedFiles.map((file, index) => ({
                        name: file.webkitRelativePath || file.name,
                        size: file.size,
                        raw: file,
                        uid: Date.now() + index + Math.random(),
                        status: 'ready'
                    }));

                    // 追加合并到现有文件列表
                    fileList.value = [...fileList.value, ...newFileItems];
                }

                nextTick(() => lucide.createIcons());
            } catch (error) {
                console.error('拖拽解析失败:', error);
                showError(translate('NoticeDragParseFailed'));
            } finally {
                publishing.value = false;
            }
        };

        const uploadRef = ref(null);
        watch(uploadRef, (newVal) => {
            if (newVal) {
                nextTick(() => {
                    const dragger = newVal.$el?.querySelector('.el-upload-dragger');
                    if (dragger) {
                        // 阻止默认拖动
                        dragger.addEventListener('dragover', (e) => {
                            e.preventDefault();
                            e.stopPropagation();
                        }, true);
                        dragger.addEventListener('drop', handleDrop, true);
                    }
                });
            }
        });
        const loadBackups = async () => {
            loadingBackUp.value = true;
            if (!selectedSite.value) return;
            try {
                const appPath = selectedApp.value?.path || '';
                const data = await deployApi.getBackups(selectedSite.value.name, appPath);
                backups.value = data;
            } catch (error) {
                showError(error.message);
            } finally {
                loadingBackUp.value = false;
            }
        };

        const checkIsReadableFile = async (file) => {
            if (!file || !(file instanceof Blob)) return false;
            try {
                if (file.size === 0) {
                    // 🌟 核心：针对 size=0 的节点，直接对原 file 进行 arrayBuffer() 测试
                    // 真实 0 字节文件会成功；文件夹节点会直接抛出 NotFoundError 被 catch 捕获
                    await file.arrayBuffer();
                } else {
                    // size > 0 的文件，只切片第 1 个字节测试句柄，避免大文件占用内存
                    await file.slice(0, 1).arrayBuffer();
                }
                return true;
            } catch (e) {
                return false; // 捕获文件夹读取异常，返回 false
            }
        };

        const publishSite = async () => {
            if (!selectedSite.value) {
                showError(translate('NoticeSelectSiteFirst'));
                return;
            }
            if (selectedServerSites.value && selectedServerSites.value.length == 0) {
                showError(translate('NoticeSelectSiteFirst'));
                return;
            }
            if (!fileList.value || fileList.value.length === 0) {
                showError(translate('NoticeSelectPackageFirst'));
                return;
            }

            publishing.value = true;

            try {
                let finalPackageFile = null;
                if (isSingleZip.value) {
                    finalPackageFile = fileList.value[0].raw;
                } else {
                    publishButtonText.value = translate('StatusPacking');
                    const zip = new JSZip();

                    // 遍历文件列表
                    for (const item of fileList.value) {
                        const rawFile = item.raw || item;
                        if (!rawFile) continue;

                        const filePath = rawFile.webkitRelativePath || item.name || rawFile.name;
                        if (!filePath) continue;

                        // 1. 如果路径明确是以 / 结尾，直接作为文件夹创建
                        if (filePath.endsWith('/')) {
                            zip.folder(filePath);
                            continue;
                        }

                        // 2. 检测节点类型：确认是可读真实文件后再添加到 ZIP
                        const isReadable = await checkIsReadableFile(rawFile);
                        if (isReadable) {
                            zip.file(filePath, rawFile); // 校验成功，仅在此处添加一次
                        } else {
                            zip.folder(filePath); // 文件夹节点，仅保留目录结构
                        }
                    }

                    // 生成 ZIP Blob 并转为 File 对象
                    const zipBlob = await zip.generateAsync({ type: 'blob' });
                    finalPackageFile = new File([zipBlob], 'publish.zip', {
                        type: 'application/zip',
                    });
                }

                if (finalPackageFile.size > 500 * 1024 * 1024) {
                    showError(translate('NoticePackageExceedLimit'));
                    return;
                }

                publishButtonText.value = translate('StatusPublishing');

                const formData = new FormData();
                formData.append('packageFile', finalPackageFile);
                formData.append('siteName', selectedSite.value.name);
                formData.append('applicationPath', selectedApp.value?.path || '');
                formData.append('backupBeforeDeploy', backupBeforeDeploy.value);
                formData.append('backupUploadFiles', backupUploadFiles.value);
                formData.append('stopBeforeDeploy', stopBeforeDeploy.value);
                formData.append('startEndDeploy', startEndDeploy.value);
                formData.append('backupExcludeDirectories', backupExcludeDirectories.value);
                formData.append('backupExcludeExtensions', backupExcludeExtensions.value);

                var selectedServerSiteList = [];
                if (selectedServerSites.value && selectedServerSites.value.length > 0) {
                    selectedServerSites.value.forEach(item => {

                        const serverUrl = item.serverUrl;
                        const site = item.site;

                        var siteExists = siteStatus.nodeUrls.find(f => f.url == serverUrl);
                        if (!siteExists) return;

                        let rawSiteName = site ? site.name : '';
                        let siteName = rawSiteName;
                        let appPath = '';

                        if (rawSiteName) {
                            const slashIndex = rawSiteName.indexOf('/');
                            if (slashIndex !== -1) {
                                // 存在 '/' 时：截取前半部分作为主站点名，后半部分作为子站点路径
                                siteName = rawSiteName.substring(0, slashIndex);
                                appPath = rawSiteName.substring(slashIndex);
                            }
                        }

                        selectedServerSiteList.push({
                            SiteUrl: serverUrl,
                            SiteName: siteName,
                            ApplicationPath: appPath
                        });
                    });
                }
                formData.append('selectedServerSitesJson', JSON.stringify(selectedServerSiteList));
                const xhr = new XMLHttpRequest();
                xhr.open('POST', `${window.appBasePath}/api/deploy/publish`);
                xhr.timeout = 20 * 60 * 1000;

                // 监听上传进度
                xhr.upload.onprogress = function (e) {
                    if (e.lengthComputable) {
                        // 计算百分比
                        const percent = Math.round((e.loaded / e.total) * 100);
                        const find = messageHubs.value.at(-1);
                        if (find.type == 'text') {
                            messageHubs.value.push({
                                type: 'percent',
                                text: `${translate('ApiUploading')}: ${percent}%`,
                                time: getNowDateTime()
                            });
                        } else {
                            find.text = `${translate('ApiUploading')}: ${percent}%`;
                        }
                    }
                };
                // 请求完成回调
                const data = await new Promise((resolve, reject) => {
                    xhr.onload = function () {
                        // 服务端返回
                        if (xhr.status >= 200 && xhr.status < 300) {
                            resolve(JSON.parse(xhr.responseText));
                        } else {
                            // 413/400/500 等错误状态码
                            try {
                                const errJson = JSON.parse(xhr.responseText);
                                reject(new Error(errJson.message || translate('NoticeRequestError', xhr.status)));
                            } catch {
                                reject(new Error(translate('NoticeServerError', xhr.status)));
                            }
                        }
                    };
                    xhr.onerror = () => reject(new Error(translate('NoticeNetworkError')));
                    xhr.abort = () => reject(new Error(translate('NoticeUploadAborted')));
                    xhr.send(formData);
                });
                if (data.code == 100) {
                    await ElementPlus.ElMessageBox.confirm(translate('ConfirmPublishText', data.message), translate('ConfirmPublishTitle'),
                        {
                            confirmButtonText: translate('ConfirmPublishBtn'),
                            cancelButtonText: translate('ActionCancel'),
                            type: 'warning',
                            dangerouslyUseHTMLString: false
                        });
                    formData.delete("packageFile");
                    formData.append('tempFile', data.tempFile);
                    await forcePublishSite(formData);
                    return;
                }
                if (data.success) {
                    showSuccess(data.message);
                    loadBackups();
                    handleSettings();
                } else {
                    showError(data.message);
                }
            } catch (error) {
                if (typeof error === 'string') {
                    showError(translate('NoticePublishFailed', error));  //Notice.PublishFailed
                } else {
                    showError(translate('NoticePublishFailed', error?.message));  //Notice.PublishFailed
                }
            } finally {
                publishing.value = false;
                publishButtonText.value = translate('LogStartPub');
                fileList.value = [];
                selectedFile.value = null;
            }
        };

        const forcePublishSite = async (formData) => {
            console.log(formData);
            const xhr = new XMLHttpRequest();
            xhr.open('POST', `${window.appBasePath}/api/deploy/forcePublishSite`);
            try {
                // 请求完成回调
                const data = await new Promise((resolve, reject) => {
                    xhr.onload = function () {
                        // 服务端返回
                        if (xhr.status >= 200 && xhr.status < 300) {
                            resolve(JSON.parse(xhr.responseText));
                        } else {
                            // 413/400/500 等错误状态码
                            try {
                                const errJson = JSON.parse(xhr.responseText);
                                reject(new Error(errJson.message || translate('NoticeRequestError', xhr.status)));
                            } catch {
                                reject(new Error(translate('NoticeServerError', xhr.status)));//NoticeServerError
                            }
                        }
                    };
                    xhr.onerror = () => reject(new Error(translate('NoticeNetworkError')));
                    xhr.abort = () => reject(new Error(translate('NoticeUploadAborted')));
                    xhr.send(formData);
                });
                if (data.success) {
                    showSuccess(data.message);
                    loadBackups();
                    handleSettings();
                } else {
                    showError(data.message);
                }
            } catch (error) {
                showError(translate('NoticePublishFailed', error?.message));  //Notice.PublishFailed
            } finally {
                publishing.value = false;
                publishButtonText.value = translate('LogStartPub');
                fileList.value = [];
                selectedFile.value = null;
            }
        };

        const rollbackSite = async (row) => {

            await ElementPlus.ElMessageBox.confirm(translate('ConfirmRollbackText', row.fileName), translate('ConfirmRollbackTitle'),
                {
                    confirmButtonText: translate('ConfirmRollbackBtn'),
                    cancelButtonText: translate('ActionCancel'),
                    type: 'warning',
                    dangerouslyUseHTMLString: false
                });

            rollingBack.value = true;
            try {
                const data = await deployApi.rollback({
                    siteName: selectedSite.value.name,
                    fileName: row.fileName,
                    applicationPath: selectedApp.value?.path || ''
                });

                if (data.success) {
                    showSuccess(data.message);
                } else {
                    showError(data.message);
                }
            } catch (error) {
                showError(translate('NoticeRollbackFailed', error?.message));
            } finally {
                rollingBack.value = false;
            }
        };

        const deleteBackup = async (row) => {
            await ElementPlus.ElMessageBox.confirm(translate('ConfirmDeleteText', row.fileName), translate('ConfirmDeleteTitle'), {
                confirmButtonText: translate('ConfirmDeleteBtn'),
                cancelButtonText: translate('ActionCancel'),
                type: 'warning',
                dangerouslyUseHTMLString: false
            });
            rollingBack.value = true;
            try {
                const data = await deployApi.deleteBackup({
                    applicationPath: selectedApp.value?.path || '',
                    siteName: selectedSite.value.name,
                    fileName: row.fileName
                });

                if (data.success) {
                    showSuccess(data.message);
                    loadBackups();
                } else {
                    showError(data.message);
                }
            } catch (error) {
                showError(translate('NoticeRollbackFailed', error?.message));
            } finally {
                rollingBack.value = false;
            }
        };

        const downloadBackup = async (row) => {
            rollingBack.value = true;
            try {
                const response = await deployApi.downloadBackup({
                    applicationPath: selectedApp.value?.path || '',
                    siteName: selectedSite.value.name,
                    fileName: row.fileName
                });

                if (!response.ok) {
                    const errorBody = await response.json();
                    showError(translate('NoticeRequestError', errorBody.message));
                    return;
                }

                const blob = await response.blob();
                const url = window.URL.createObjectURL(blob);

                const a = document.createElement("a");
                a.href = url;
                a.download = row.fileName;
                document.body.appendChild(a);
                a.click();

                a.remove();
                window.URL.revokeObjectURL(url);

            } catch (error) {
                showError(error.message);
            } finally {
                rollingBack.value = false;
            }
        };

        const showSuccess = (message) => {
            showNotice(message, 'success', 2000);
        };

        const showError = (message) => {
            showNotice(message, 'error');
        };

        const stopSite = async () => {
            try {
                const data = await deployApi.stopSite({
                    siteName: selectedSite.value.name,
                    applicationPath: selectedApp.value?.path || ''
                });

                if (data.success) {
                    showSuccess(data.message);
                    selectedSite.value.state = 'Stopped';
                } else {
                    showError(data.message);
                }
            } catch (error) {
                showError(translate('NoticeStopFailed', error?.message));
            } finally {
                rollingBack.value = false;
                nextTick(() => lucide.createIcons());
            }
        };

        const startSite = async () => {
            try {
                const data = await deployApi.startSite({
                    siteName: selectedSite.value.name,
                    applicationPath: selectedApp.value?.path || ''
                });

                if (data.success) {
                    showSuccess(data.message);
                    selectedSite.value.state = 'Started';
                } else {
                    showError(data.message);
                }

            } catch (error) {
                showError(translate('NoticeStartFailed', error?.message));
            } finally {
                rollingBack.value = false;
                nextTick(() => lucide.createIcons());
            }
        };

        const logout = async () => {
            window.location.href = `${window.appBasePath}/api/auth/logout`;
        }
        const changeLan = async (lan) => {
            await authApi.setLanguage(lan);
            location.reload();
        };
        const changePage = async (page) => {
            pageName.value = page;
            if (page == 'pool') {
                await getAppPools();
            }
            if (page == 'user') {
                await getUsers();
            }
        }
        //==========add site
        const createSiteDialogVisible = ref(false);
        const createSiteLoading = ref(false);
        const createSiteFormRef = ref();
        const createSiteForm = reactive({
            name: '',
            applicationPath: '',
            physicalPath: '',
            appPool: '',
            ip: '*',
            bindingProtocol: 'http',
            port: 80,
            host: '',
            maxAllowedContentLengthMB: 28
        });
        const iisBindFormRef = ref(null);
        const iisBindDialog = reactive({
            visible: false,
            isEdit: false,
            rules: null,
            loading: false,
            bindings: [],
            form: {
                protocol: '',
                ip: '',
                port: '',
                host: '',
            }
        });
        const openBindingDialog = async () => {
            await loadServerIps();
            const targetSource = selectedApp.value || selectedSite.value
            const bindingsInfos = targetSource?.bindingsInfos || []

            iisBindDialog.isEdit = bindingsInfos.length > 0
            iisBindDialog.bindings = []

            if (bindingsInfos.length > 0) {
                // 将后端返回的多条数据映射入数组
                iisBindDialog.bindings = bindingsInfos.map(bind => ({
                    protocol: bind[0] || 'http',
                    ip: bind[1] || '*',
                    port: Number(bind[2]) || 80,
                    host: bind[3] || ''
                }))
            } else {
                // 初始无绑定时默认给一行
                addBindingRow()
            }
            iisBindDialog.visible = true;
        };
        const addBindingRow = () => {
            iisBindDialog.bindings.push({
                protocol: 'http',
                ip: '*',
                port: 80,
                host: ''
            })
        }
        const removeBindingRow = (index) => {
            iisBindDialog.bindings.splice(index, 1)
        };
        const handleIISBindSubmit = async () => {
            if (!iisBindFormRef.value) return

            await iisBindFormRef.value.validate(async (valid) => {
                if (!valid) return

                iisBindDialog.loading = true
                try {
                    const payload = {
                        siteName: selectedSite.value.name,
                        appName: selectedApp.value?.name || null,
                        isEdit: iisBindDialog.isEdit,
                        bindings: iisBindDialog.bindings
                    }
                    const body = await deployApi.saveBindings(payload);
                    showSuccess(body.message);
                    iisBindDialog.visible = false;
                } catch (error) {
                    showError(error.message);
                } finally {
                    iisBindDialog.loading = false;
                    refreshSites();
                }
            })
        };

        const restartSite = async () => {
            try {
                var siteName = selectedSite.value.name;
                const body = await deployApi.restartSite(siteName);
                showSuccess(body.message);
            } catch (err) {
                showError(err.message);
            }
        };

        const createSiteRules = reactive({
            name: [
                { required: true, message: translate('SiteSiteNameRequired'), trigger: 'blur' },
                { pattern: /^[a-zA-Z0-9_\-\.\s]+$/, message: translate('SiteSiteNameInvalid'), trigger: 'blur' }
            ],
            physicalPath: [
                { required: true, message: translate('SitePhysicalPathRequired'), trigger: 'blur' }
            ],
            appPool: [
                { required: true, message: translate('SiteSelectAppPool'), trigger: 'change' }
            ],
            port: [
                { required: true, message: translate('SitePortRequired'), trigger: 'blur' }
            ]
        });
        const serverIps = ref([]);
        const ipOptions = computed(() => [
            {
                label: translate('SiteAllUnassigned'),
                value: '*'
            },
            ...serverIps.value.map(ip => ({
                label: ip,
                value: ip
            }))
        ]);
        const protocolOptions = ref([{
            label: 'http',
            value: 'http'
        }, {
            label: 'https',
            value: 'https'
        }]);
        const loadServerIps = async () => {
            try {
                serverIps.value = await deployApi.getServerIps();
            } catch (error) {
                showError(error.message);
            }
        };
        const inputRef = ref(null);
        const popoverWidth = ref(350);
        const updateSiteType = ref('');
        const showAddSiteDialog = async () => {
            updateSiteType.value = 'add';
            await getAppPools();
            await loadServerIps();
            createSiteForm.name = '';
            //默认池
            createSiteForm.appPool = pools.value[0].name;
            createSiteDialogVisible.value = true;
            nextTick(() => lucide.createIcons());
        };
        const openAddApplication = async () => {
            updateSiteType.value = 'addapp';
            await getAppPools();
            await loadServerIps();
            createSiteForm.name = '';
            createSiteForm.appPool = pools.value[0].name;
            createSiteForm.physicalPath = selectedSite.value.physicalPath;
            createSiteDialogVisible.value = true;
            nextTick(() => lucide.createIcons());
        };
        const updatePopoverWidth = async () => {
            if (inputRef.value?.$el) {
                popoverWidth.value = inputRef.value.$el.getBoundingClientRect().width
            }
        };
        const popoverRef = ref(null)
        const handleSitePathClick = async (data) => {
            if (data && data.path) {
                createSiteForm.physicalPath = data.path;
                popoverRef.value?.hide();
            }
            nextTick(() => lucide.createIcons());
        };
        const submitCreateSite = async () => {
            if (updateSiteType.value == 'basic') {
                await submitBasicSite();
                return
            }
            if (updateSiteType.value == 'addapp') {
                await submitAddApp();
                return
            }
            createSiteFormRef.value?.validate(async (valid) => {
                if (!valid) return
                createSiteLoading.value = true
                try {
                    const body = await deployApi.createSite(createSiteForm);
                    showSuccess(body.message);
                    createSiteDialogVisible.value = false;
                } catch (err) {
                    showError(err.message);
                } finally {
                    createSiteLoading.value = false;
                    refreshSites();
                }
            })
        };
        const submitBasicSite = async () => {
            createSiteFormRef.value?.validate(async (valid) => {
                if (!valid) return
                createSiteLoading.value = true;
                try {
                    createSiteForm.name = selectedSite.value.name;
                    const body = await deployApi.updateSiteBasic(createSiteForm);
                    showSuccess(body.message);
                    createSiteDialogVisible.value = false;
                } catch (err) {
                    showError(err.message);
                } finally {
                    createSiteLoading.value = false;
                    refreshSites();
                }
            });
        };
        const submitAddApp = async () => {
            createSiteFormRef.value?.validate(async (valid) => {
                if (!valid) return
                createSiteLoading.value = true;
                debugger;
                try {
                    var obj = {
                        siteName: selectedSite.value.name,
                        appPath: createSiteForm.name,
                        physicalPath: createSiteForm.physicalPath,
                        appPool: createSiteForm.appPool
                    };
                    const body = await deployApi.createApp(obj);
                    showSuccess(body.message);
                    createSiteDialogVisible.value = false;
                } catch (err) {
                    showError(err.message);
                } finally {
                    createSiteLoading.value = false;
                    refreshSites();
                }
            });
        };
        const openEditSite = async () => {
            updateSiteType.value = 'basic';
            await getAppPools();
            await loadServerIps();
            createSiteDialogVisible.value = true;
            createSiteForm.name = selectedSite.value.name;
            if (selectedApp?.value != null) createSiteForm.name = trimSpecial(selectedApp?.value.path);
            createSiteForm.appPool = selectedApp?.value?.appPool || selectedSite.value.appPool;
            createSiteForm.physicalPath = selectedApp?.value?.physicalPath || selectedSite.value.physicalPath;
            createSiteForm.applicationPath = selectedApp?.value?.path;
            createSiteForm.maxAllowedContentLengthMB = selectedApp?.value?.maxAllowedContentLengthMB || selectedSite.value.maxAllowedContentLengthMB;
            nextTick(() => lucide.createIcons());
        };
        var deleteSiteLoading = ref(false);
        const deleteSite = async () => {
            var siteName = selectedSite.value.name;
            var appPath = selectedApp.value?.path ?? '';
            await ElementPlus.ElMessageBox.confirm(translate('ConfirmDeleteTitle'), translate('ConfirmDeleteTitle'), {
                confirmButtonText: translate('ConfirmDeleteBtn'),
                cancelButtonText: translate('ActionCancel'),
                type: 'warning',
                dangerouslyUseHTMLString: false
            });
            deleteSiteLoading.value = true;
            try {
                const body = await deployApi.deleteSite(siteName, appPath, currentAppId.value);
                showSuccess(body.message);
                selectedSite.value = null;
                selectedApp.value = null;
            } catch (err) {
                showError(err.message);
            } finally {
                deleteSiteLoading.value = false;
                refreshSites();
            }
        };
        const treeProps = {
            label: 'path',     // 节点显示的名称
            value: 'path',     // 选中后赋予 v-model 的完整路径
            isLeaf: 'isLeaf'   // 标识是否为叶子节点 (没有子文件夹时不显示展开图标)
        }
        // 3. 懒加载读取服务器目录逻辑
        const loadDirectoryNodes = async (node, resolve) => {
            // node.level === 0 代表根节点首次加载，传空 path 请求服务器盘符列表
            const currentPath = node.level === 0 ? '' : node.data.path
            try {
                const res = await deployApi.getDirectories(currentPath);
                if (res && Array.isArray(res)) {
                    const nodes = res.map(item => ({
                        name: item.name,
                        path: item.path,
                        isLeaf: !item.hasChildren
                    }))
                    resolve(nodes)
                } else {
                    resolve([])
                }
            } catch (error) {
                console.error('加载目录结构失败:', error)
                resolve([])
            }
        }

        //==========polls
        const pools = ref([]);
        const pollSearch = ref('');
        const selectedPool = ref(null);
        const pollLoading = ref(false);
        const poolStartLoading = ref(false);
        const poolEndLoading = ref(false);
        const poolRecycleLoading = ref(false);
        const poolSaveLoading = ref(false);
        const createDialogVisible = ref(false);
        const createLoading = ref(false);
        const deletePoolLoading = ref(false);
        const renameDialogVisible = ref(false);
        const poolRenameLoading = ref(false);
        const newPoolName = ref('');
        const renameSiteDialogVisible = ref(false);
        const newSiteName = ref('');
        const createForm = reactive({
            name: '',
            clrVersion: 'v4.0',
            managedPipelineMode: 'Integrated' // 默认值设为 Integrated
        });

        const submitRenameSite = async () => {
            poolRenameLoading.value = true;
            try {
                const body = await deployApi.renameSite(selectedSite.value.name, newSiteName.value, currentAppId.value);
                showSuccess(body.message);
                renameSiteDialogVisible.value = false;
                selectedSite.value.name = newSiteName.value;
            } catch (err) {
                showError(err.message);
            } finally {
                poolRenameLoading.value = false;
            }
        };
        const submitRenamePool = async () => {
            poolRenameLoading.value = true;
            try {
                const body = await deployApi.renamePool(selectedPool.value.name, newPoolName.value);
                showSuccess(body.message);
                renameDialogVisible.value = false;
                selectedPool.value.name = newPoolName.value;
            } catch (err) {
                showError(err.message);
            } finally {
                poolRenameLoading.value = false;
            }
        };
        const submitCreatePool = async () => {
            createLoading.value = true;
            try {
                const body = await deployApi.createPool(createForm);
                showSuccess(body.message);
            } catch (err) {
                showError(err.message);
            } finally {
                createLoading.value = false;
                createDialogVisible.value = false;
                getAppPools();
            }
        };
        const handleDeletePool = async () => {
            var poolName = selectedPool.value.name;

            await ElementPlus.ElMessageBox.confirm(translate('ConfirmDeleteTitle', poolName), translate('ConfirmDeleteTitle'), {
                confirmButtonText: translate('ConfirmDeleteBtn'),
                cancelButtonText: translate('ActionCancel'),
                type: 'warning',
                dangerouslyUseHTMLString: false
            });
            deletePoolLoading.value = true;
            try {
                const body = await deployApi.deletePool(poolName);
                showSuccess(body.message);
            } catch (err) {
                showError(err.message);
            } finally {
                deletePoolLoading.value = false;
                getAppPools();
            }
        };
        const getAppPools = async () => {
            pollLoading.value = true;
            try {
                pools.value = await deployApi.getAppPools();
            } catch (error) {
                pools.value = [];
                showError(error.message);
            } finally {
                pollLoading.value = false;
            }
        }
        const selectPool = async (pool) => {
            selectedPool.value = pool;
            nextTick(() => lucide.createIcons());
        };
        const startPool = async () => {
            poolStartLoading.value = true;
            try {
                var name = selectedPool.value.name;
                const body = await deployApi.startPool(name);
                selectedPool.value.status = 'Started';
                showSuccess(body.message);
            } catch (error) {
                showError(error.message);
            } finally {
                poolStartLoading.value = false;
            }
        };
        const stopPool = async () => {
            poolEndLoading.value = true;
            try {
                var name = selectedPool.value.name;
                const body = await deployApi.stopPool(name);
                selectedPool.value.status = 'Stopped';
                showSuccess(body.message);
            } catch (error) {
                showError(error.message);
            } finally {
                poolEndLoading.value = false;
            }
        };
        const recyclePool = async () => {
            poolRecycleLoading.value = true;
            try {
                var name = selectedPool.value.name;
                const body = await deployApi.recyclePool(name);
                showSuccess(body.message);
            } catch (error) {
                showError(error.message);
            } finally {
                poolRecycleLoading.value = false;
            }
        };
        const savePoolSettings = async () => {
            if (!selectedPool.value) return;
            poolSaveLoading.value = true;
            try {
                const body = await deployApi.savePoolSettings(selectedPool.value);
                showSuccess(body.message);
            } catch (err) {
                showError(err.message);
            } finally {
                poolSaveLoading.value = false;
                getAppPools();
            }
        }
        const filteredPools = computed(() => {
            const keyword = pollSearch.value.trim().toLowerCase();
            const poolArr = Array.isArray(pools.value) ? pools.value : [];

            if (!keyword) {
                return poolArr;
            }

            return poolArr.filter(pool =>
                pool.name.toLowerCase().includes(keyword)
            );
        });
        ////////////////logs/////////////////
        const logDialogVisible = ref(false);
        const logLoading = ref(false);
        const logQuery = reactive({
            user: '',
            action: '',
            dateRange: [],
            pageIndex: 1,
            pageSize: 10
        });
        const logData = reactive({
            total: 0,
            items: []
        });
        const showLogs = async (name) => {
            logDialogVisible.value = true;
            logLoading.value = true;
            if (name) logQuery.user = name;
            await fetchLogs();
        };
        const handleSearch = () => {
            logQuery.pageIndex = 1;
            fetchLogs();
        };
        const resetSearch = () => {
            logQuery.user = '';
            logQuery.action = '';
            logQuery.pageIndex = 1;
            fetchLogs();
        };
        const getDurationTagType = (duration) => {
            if (duration < 100) return 'success';
            if (duration < 500) return 'warning';
            return 'danger';
        };
        const fetchLogs = async () => {
            logLoading.value = true;
            try {
                const params = new URLSearchParams({
                    user: logQuery.user,
                    action: logQuery.action,
                    pageIndex: logQuery.pageIndex,
                    pageSize: logQuery.pageSize
                });
                if (logQuery.dateRange && logQuery.dateRange.length === 2) {
                    const start = logQuery.dateRange[0];
                    const end = logQuery.dateRange[1];

                    if (start) params.append('start', start);
                    if (end) params.append('end', end);
                }

                const res = await userApi.getLogs(params);
                logData.total = res.total || 0;
                logData.items = res.items || [];

                nextTick(() => {
                    if (window.lucide) {
                        window.lucide.createIcons();
                    }
                });
            } catch (err) {
                logData.total = 0;
                logData.items = [];
                showError(err.message || translate('IISErr_LoadOperationLogFailed'));
            } finally {
                logLoading.value = false;
            }
        };

        ////////////////user////////////////
        const userSearch = ref('');
        const selectedUser = ref(null);
        const originalUserPermission = ref(null);  //重置权限项用
        const users = ref([]);
        const filteredUsers = computed(() => {
            const keyword = userSearch.value.trim().toLowerCase();
            if (!keyword) {
                return users.value;
            }
            return users.value.filter(user =>
                user.userName.toLowerCase().includes(keyword)
            );
        });

        const addUserDialog = ref(false);
        const userMode = ref('add');
        const userFormRef = ref(null);
        const submitUserLoading = ref(false);
        const userForm = reactive({
            id: '',
            username: '',
            password: '',
            isEnabled: true
        });
        const userRules = reactive({
            username: [
                { required: true, message: translate('ValidationRequireUsername'), trigger: 'blur' },
                { min: 3, max: 20, message: translate('ValidationUsernameLength'), trigger: 'blur' }
            ],
            password: [
                { required: true, message: translate('ValidationRequirePassword'), trigger: 'blur' },
                { min: 6, max: 20, message: translate('ValidationPasswordLength'), trigger: 'blur' }
            ]
        });
        const addUserDialogShow = async () => {
            addUserDialog.value = true;
            userMode.value = 'add';
        };
        const handleUserEditShow = async (user) => {
            addUserDialog.value = true;
            userMode.value = 'update';
            userForm.id = user.id;
            userForm.username = user.userName;
            userForm.isEnabled = user.enabled;
        };
        const handleUserSubmit = async () => {
            if (!userFormRef.value) return
            await userFormRef.value.validate(async (valid) => {
                if (valid) {
                    submitUserLoading.value = true
                    try {
                        let body;
                        if (userMode.value == 'update') {
                            body = await userApi.updateUser(userForm);
                        } else {
                            body = await userApi.addUser(userForm);
                        }
                        showSuccess(body.message);
                        addUserDialog.value = false;
                    } catch (error) {
                        showError(error.message);
                    } finally {
                        submitUserLoading.value = false;
                        getUsers();
                    }
                }
            })
        }
        const enableUser = async (id, enabled) => {
            userLoading.value = true;
            try {
                const body = await userApi.enableUser(id, enabled);
                showSuccess(body.message);
                getUsers();
            } catch (error) {
                showError(error.message);
            } finally {
                userLoading.value = false;
            }
        };
        const userLoading = ref(false);
        const getUsers = async () => {
            try {
                userLoading.value = true;
                users.value = await userApi.getUsers();
            } catch (error) {
                users.value = [];
                showError(error.message);
            } finally {
                userLoading.value = false;
            }
        };
        const selectUser = (user) => {
            selectedUser.value = user;
            originalUserPermission.value = JSON.parse(JSON.stringify(user.permission));
            nextTick(() => lucide.createIcons());
        };
        const setAllKeysValue = (obj, value) => {
            if (!obj || typeof obj !== 'object') return;
            Object.keys(obj).forEach(key => {
                if (typeof obj[key] === 'object' && obj[key] !== null) {
                    setAllKeysValue(obj[key], value);
                } else if (typeof obj[key] === 'boolean') {
                    obj[key] = value;
                }
            });
        };
        // 检查某个权限对象下的布尔值是否已全部为 true
        const isAllSelected = (target) => {
            if (!target) return false;
            const isObject = (val) => typeof val === 'object' && val !== null;
            const permObj = isObject(target.permission) ? target.permission : target;

            const values = Object.values(permObj).filter(val => typeof val === 'boolean');
            return values.length > 0 && values.every(Boolean);
        };
        // 切换选择状态：如果全选则置为 false，否则置为 true
        const togglePermissionGroup = (target) => {
            if (!target) return;
            const isObject = (val) => typeof val === 'object' && val !== null;
            const permObj = isObject(target.permission) ? target.permission : target;

            const allTrue = isAllSelected(permObj);
            setAllKeysValue(permObj, !allTrue);
        };
        const setAllKeysTrue = (obj) => {
            if (!obj || typeof obj !== 'object') return;
            Object.keys(obj).forEach(key => {
                if (typeof obj[key] === 'object' && obj[key] !== null) {
                    setAllKeysTrue(obj[key]);
                } else {
                    obj[key] = true;
                }
            });
        };
        const selectSitePermission = () => togglePermissionGroup(selectedUser.value.permission.site);
        const selectUserPermission = () => togglePermissionGroup(selectedUser.value.permission.user);
        const selectAppPoolPermission = () => togglePermissionGroup(selectedUser.value.permission.appPool);

        const selectAllSystemPermissions = () => {
            const { site, user, appPool } = selectedUser.value.permission;
            // 如果三者都已全选，则全不选；否则全部设为 true
            const allTrue = isAllSelected(site) && isAllSelected(user) && isAllSelected(appPool);
            setAllKeysValue(site, !allTrue);
            setAllKeysValue(user, !allTrue);
            setAllKeysValue(appPool, !allTrue);
        };

        const selectAllSitePermission = (site) => {
            if (!site) return;
            const targetSite = typeof site === 'string'
                ? selectedUser.value.permission.sites.find(s => s.siteId === site || s.name === site)
                : site;

            if (targetSite) {
                togglePermissionGroup(targetSite.permission);
            }
        };
        const selectAllSitePermissions = () => {
            const sites = selectedUser.value.permission.sites;
            const allTrue = sites.every(s => isAllSelected(s.permission));
            sites.forEach(s => setAllKeysValue(s.permission, !allTrue));
        };
        const getPermissionCount = (user) => {
            if (!user || !user.permission) return 0;

            // 兼容 permission 为 JSON 字符串的情况
            const permission = typeof user.permission === 'string'
                ? JSON.parse(user.permission)
                : user.permission;

            let trueCount = 0;

            // 递归统计对象内部值为 true 的布尔节点
            const countTrueKeys = (obj) => {
                if (!obj || typeof obj !== 'object') return;

                Object.keys(obj).forEach(key => {
                    const val = obj[key];
                    if (val === true) {
                        trueCount++;
                    } else if (typeof val === 'object' && val !== null) {
                        countTrueKeys(val);
                    }
                });
            };

            // 1. 统计系统权限 (site, user, appPool)
            if (permission.site) countTrueKeys(permission.site);
            if (permission.user) countTrueKeys(permission.user);
            if (permission.appPool) countTrueKeys(permission.appPool);

            // 2. 统计所有站点权限 (sites 数组)
            if (Array.isArray(permission.sites)) {
                permission.sites.forEach(site => {
                    if (site && site.permission) {
                        countTrueKeys(site.permission);
                    }
                });
            }
            return trueCount;
        };
        const getSitePermissionSummary = (target) => {
            if (!target) return translate('StatusUnauthorized');

            // 只有当 target.permission 是一个【纯对象】且非 null 时，才取 target.permission
            // 避免 target.permission 为 true/false 布尔值时误入分支
            const isObject = (val) => typeof val === 'object' && val !== null;
            const permObj = isObject(target.permission) ? target.permission : target;

            // 过滤出所有布尔类型的权限字段进行统计
            const values = Object.values(permObj).filter(val => typeof val === 'boolean');
            const count = values.filter(Boolean).length;
            const total = values.length;

            if (count === 0) return translate('StatusUnauthorized');
            return `${translate('StatusAuthorized')} ${count} / ${total} ${translate('CommonItems')}`;
        };
        const hasShowSettings = (appId) => {
            // 1. 基本配置
            const canShowSettings = hasPermission('settings', appId);
            // 2. 站点重命名（仅主站点，且有权限）
            const canShowRename = selectedApp.value === null && hasPermission('rename', appId);
            // 3. IIS 绑定（仅主站点，且有权限）
            const canShowBinding = selectedApp.value === null && hasPermission('binding', appId);
            // 4. 添加应用程序（仅主站点，且有权限）
            const canShowAddApp = selectedApp.value === null && hasPermission('addApp', appId);
            // 5. 重启
            const canShowRestart = hasPermission('restart', appId);
            // 6. 删除站点/应用程序
            const canShowDelete = hasPermission('deleteSite', appId);
            // 只要有任意一个子菜单满足显示条件，整个下拉菜单就显示
            return canShowSettings || canShowRename || canShowBinding || canShowAddApp || canShowRestart || canShowDelete;
        };
        const hasShowCommonActions = () => {
            // 1. 启动权限
            const canStart = hasPermission('appPool.start');
            // 2. 停止权限
            const canStop = hasPermission('appPool.stop');
            // 3. 回收权限
            const canRecycle = hasPermission('appPool.recycle');
            // 4. 重命名权限
            const canRename = hasPermission('appPool.rename');
            // 5. 删除权限
            const canDelete = hasPermission('appPool.delete');
            // 只要有任意一个卡片允许显示，整个 settings-card 就显示
            return canStart || canStop || canRecycle || canRename || canDelete;
        };
        const resetUserPermission = async () => {
            if (!originalUserPermission.value) return;
            // 将副本重新深拷贝赋给当前用户对象
            selectedUser.value.permission = JSON.parse(JSON.stringify(originalUserPermission.value));
        };
        const deleteUser = async () => {
            await ElementPlus.ElMessageBox.confirm(translate('ConfirmDeleteTitle'), translate('ConfirmDeleteTitle'), {
                confirmButtonText: translate('ConfirmDeleteBtn'),
                cancelButtonText: translate('ActionCancel'),
                type: 'warning',
                dangerouslyUseHTMLString: false
            });
            submitUserLoading.value = true;
            try {
                const body = await userApi.deleteUser(selectedUser.value.id);
                showSuccess(body.message);
            } catch (error) {
                showError(error.message);
            } finally {
                submitUserLoading.value = false;
                getUsers();
            }
        };
        const saveUserPermission = async () => {
            submitUserLoading.value = true
            try {
                const permissionData = JSON.parse(JSON.stringify(selectedUser.value.permission || {}));
                if (Array.isArray(permissionData.sites)) {
                    permissionData.sites = permissionData.sites.filter(site => {
                        if (!site.permission) return false;
                        return Object.values(site.permission).some(value => value === true);
                    });
                }
                var obj = {
                    id: selectedUser.value.id,
                    permission: permissionData
                };
                const body = await userApi.updateUserPermission(obj);
                showSuccess(body.message);
            } catch (error) {
                showError(error.message);
            } finally {
                submitUserLoading.value = false;
                getUsers();
            }
        };
        const getUserInitial = (name) => {
            return name ? name.substring(0, 1) : '?';
        };

        //多服务器节点选择
        const siteDeploySettingDialog = ref(false);
        // 1. 响应式变量
        const selectedServerSites = ref([]);
        // Dialog 内部使用的临时变量（暂存区）
        const tempSelectedServerSites = ref([]);
        const deploySiteListLoading = ref(false);
        // 2. 服务器与站点树形数据
        const serverList = ref([]);

        const showSiteDeploySettingDialog = async () => {

            tempSelectedServerSites.value = [...selectedServerSites.value];
            siteDeploySettingDialog.value = true;
            deploySiteListLoading.value = true;

            try {
                // 1. 使用 Promise.all 同时并行请求所有 nodeUrls
                const promises = (siteStatus.nodeUrls || []).map(nodeUrl =>
                    getDeploySiteList({ headers: { 'site-url': nodeUrl.url } })
                );

                const results = await Promise.all(promises);

                // 2. 将所有节点返回的结果组合并 push 到 serverList 中
                const allServers = [];
                results.forEach(res => {
                    if (res) {
                        // 如果接口返回的是数组，则展开合并；如果是单个对象，则直接 push
                        if (Array.isArray(res)) {
                            allServers.push(...res);
                        } else {
                            allServers.push(res);
                        }
                    }
                });

                serverList.value = allServers;

            } catch (error) {
                showError(error.message);
                serverList.value = [];
            } finally {
                deploySiteListLoading.value = false;
                await nextTick();
                lucide.createIcons();
            }
        }

        const getDeploySiteList = async (options = {}) => {
            try {
                return await deployApi.getDeploySiteList(options);
            } catch (error) {
                showError(error.message);
                return null;
            }
        }
        const saveSiteDeploySetting = async () => {
            // 1. 过滤出合法的选中项（保留你原有的校验逻辑）
            const validSelectedSites = tempSelectedServerSites.value.filter(item => {
                if (!item || !item.serverUrl || !item.site) return false;
                return serverList.value.some(server =>
                    server.url === item.serverUrl &&
                    Array.isArray(server.sitePermissionItem) &&
                    server.sitePermissionItem.some(site => site.siteId === item.site.siteId)
                );
            });

            // 2. 按照 serverList 的顺序对选中的项进行排序
            validSelectedSites.sort((a, b) => {
                const indexA = serverList.value.findIndex(s => s.url === a.serverUrl);
                const indexB = serverList.value.findIndex(s => s.url === b.serverUrl);
                if (indexA !== indexB) return indexA - indexB;

                const serverA = serverList.value[indexA];
                const serverB = serverList.value[indexB];
                const siteIndexA = serverA.sitePermissionItem.findIndex(site => site.siteId === a.site.siteId);
                const siteIndexB = serverB.sitePermissionItem.findIndex(site => site.siteId === b.site.siteId);
                return siteIndexA - siteIndexB;
            });

            if (validSelectedSites.length > 0) {
                var selectedServerUrl = validSelectedSites[0].serverUrl;
                var selectedSiteId = validSelectedSites[0].site.siteId;
                if (selectedServerUrl != currentSiteItem.value.url) {
                    var nodeUrl = siteStatus.nodeUrls.find(f => f.url == selectedServerUrl);
                    if (nodeUrl) handleNodeSwitch(nodeUrl);
                }
                if (selectedSiteId != currentAppId.value) {
                    CookieUtil.set('currentSelectSiteId', selectedSiteId);
                    restoreSelectedNode();
                }
            }
            nextTick(() => selectedServerSites.value = validSelectedSites);
            siteDeploySettingDialog.value = false;
        }
        /**
         * 校验当前用户是否拥有指定的权限
         * @param {string} permissionName 权限名称，例如 "start"、"user.view"、"sites.app01.start"
         * @param {string} [siteId] 可选，站点 ID（如果针对特定站点判断，可直接在此传入）
         * @returns {boolean} 是否拥有权限
         */
        const hasPermission = (permissionName, siteId = null) => {
            if (initialUser == 'admin') return true;
            if (!userPermission || !permissionName) return false;
            try {
                // 1. 辅助函数：校验 sites 数组中对应站点的权限
                const checkSitePermission = (targetSiteId, action) => {
                    if (!Array.isArray(userPermission.sites)) return false;

                    // 匹配 siteId 或 name 相同的站点
                    const site = userPermission.sites.find(s =>
                        s.siteId === targetSiteId || s.name === targetSiteId
                    );

                    if (!site || !site.permission) return false;
                    return Boolean(site.permission[action]);
                };

                // 场景 1：显式指定了 siteId 参数
                // 例如：hasPermission(userPermission, 'start', 'app01')
                if (siteId) {
                    return checkSitePermission(siteId, permissionName);
                }

                // 场景 2：支持传递 "sites.app01.start" 格式的字符串
                const parts = permissionName.split('.');
                if (parts.length === 3 && parts[0].toLowerCase() === 'sites') {
                    const targetSiteId = parts[1];
                    const action = parts[2];
                    return checkSitePermission(targetSiteId, action);
                }
                // 场景 3：常规的全局对象路径匹配，例如 "user.view" 或 "site.create"
                let current = userPermission;
                for (const part of parts) {
                    if (current && typeof current === 'object' && part in current) {
                        current = current[part];
                    } else {
                        return false;
                    }
                }
                return Boolean(current === true);
            } catch (e) {
                console.error("权限解析异常:", e);
                return false;
            }
        }

        // 4. 服务器全选 / 半选辅助逻辑
        function isServerAllSelected(serverId) {
            const server = serverList.value.find(s => s.id === serverId);
            if (!server) return false;
            return server.sites.every(site => selectedServerSites.value.includes(site.id));
        }

        function isServerIndeterminate(serverId) {
            const server = serverList.value.find(s => s.id === serverId);
            if (!server) return false;
            const count = server.sites.filter(site => selectedServerSites.value.includes(site.id)).length;
            return count > 0 && count < server.sites.length;
        }

        const pollingTimer = ref(null);
        const isPolling = ref(false);
        const loading = ref(false);
        const siteStatus = reactive({
            nodeUrls: window.nodeUrls
        });
        async function loadSiteStatus() {
            const tasks = [];
            // 2. 处理 Slave 节点列表连接测试
            if (siteStatus.nodeUrls && siteStatus.nodeUrls.length > 0) {
                siteStatus.nodeUrls.forEach(node => {
                    if (node && node.url) {
                        tasks.push(testConnection(node.url).then(isOk => {
                            node.enabled = isOk;
                        }));
                    }
                });
            }
            // 3. 并行等待所有节点的连接测试完成
            await Promise.all(tasks);
        }
        const handleNodeSwitch = async (item) => {
            currentSiteItem.value = item;
            refreshSites();
        }
        async function testConnection(targetUrl) {
            try {
                if (targetUrl == currentServerUrl) return true;
                const body = await authApi.testConnection(targetUrl);
                return !!body.success;
            } catch (err) {
                showError(err.message);
                return false;
            }
        }
        function startPolling(fetchFn, interval = 3000) {
            if (isPolling.value) return
            isPolling.value = true

            // 立即执行一次
            runTask(fetchFn, interval)
        }

        async function runTask(fetchFn, interval) {
            if (!isPolling.value) return
            loading.value = true
            try {
                await fetchFn()
            } catch (err) {
                console.error('轮询异常：', err)
            } finally {
                loading.value = false
                // 继续下一轮
                if (isPolling.value) {
                    pollingTimer.value = setTimeout(() => {
                        runTask(fetchFn, interval)
                    }, interval)
                }
            }
        }
        function stopPolling() {
            isPolling.value = false
            if (pollingTimer.value) {
                clearTimeout(pollingTimer.value)
                pollingTimer.value = null
            }
        }

        const messageHubs = ref([]);
        let connection = null;
        let signalrInited = false;
        const createConnection = async () => {
            // 1. 无选中站点直接终止
            if (!selectedSite.value) {
                return;
            }
            // 2. 已初始化过直接返回，避免重复创建
            if (signalrInited && connection?.state === signalR.HubConnectionState.Connected) {
                // 仅重新切换分组
                const groupId = getAppId();
                await connection.invoke("JoinSiteGroup", groupId);
                messageHubs.value = [{
                    type: 'text',
                    text: translate('SignalRConnectSuccess'),
                    time: getNowDateTime()
                }];
                return;
            }

            connection = new signalR.HubConnectionBuilder()
                .withUrl(`${window.appBasePath}/hub/publish`, {
                    withCredentials: true
                })
                .withAutomaticReconnect([1000, 2000, 4000, 8000, 15000])
                .build();

            // 安全加入分组
            const safeJoinGroup = async (sid) => {
                if (!sid || sid.trim() === "") return;
                await connection.invoke("JoinSiteGroup", sid);
                messageHubs.value = [{
                    type: 'text',
                    text: translate('SignalRConnectSuccess'),//SignalR.ConnectSuccess
                    time: getNowDateTime()
                }];
            };

            connection.onreconnecting(() => {
                console.log("网络断开，正在重连...");
            });

            // 重连成功重新加入分组
            connection.onreconnected(async () => {
                const groupId = getAppId();
                await safeJoinGroup(groupId);
                console.log("重连成功，恢复站点订阅");
            });

            // 连接关闭鉴权跳转
            connection.onclose(err => {
                signalrInited = false;
                if (err && err.statusCode === 401) {
                    showNotice(translate('SignalRAuthExpired'), "error");
                    setTimeout(() => location.href = `${window.appBasePath}/api/auth/login`, 1200);
                }
            });

            // 接收后端发布进度
            connection.on("PublishProgress", (value) => {
                if (value.type === 'text') {
                    messageHubs.value.push({
                        type: value.type,
                        text: value.text,
                        time: getNowDateTime()
                    });
                } else {
                    const progress = messageHubs.value.at(-1);
                    if (progress.type == 'percent') {
                        progress.text = value.text;
                        progress.time = getNowDateTime();
                    } else {
                        messageHubs.value.push({
                            type: value.type,
                            text: value.text,
                            time: getNowDateTime()
                        });
                    }
                }
            });
            connection.on("SiteConnectionCountChanged", count => {
                currentSiteUsers.value = count;
            });
            connection.on("TotalConnectionCountChanged", count => {
                totalSiteUsers.value = count;
            });

            // 启动连接
            await connection.start();
            signalrInited = true;

            // 加入当前站点分组
            const groupId = getAppId();
            await safeJoinGroup(groupId);
        };

        const initConnection = async () => {
            if (selectedSite.value) {
                await createConnection();
            } else {
                // 切换到根节点，无站点则断开连接
                if (signalrInited && connection) {
                    await connection.stop();
                    signalrInited = false;
                }
            }
        };

        onMounted(async () => {
            refreshSites();
            lucide.createIcons();
            startPolling(loadSiteStatus, 30000);
        });

        onUnmounted(async () => {
            if (connection) {
                const appId = getAppId();
                await connection.invoke("LeaveSiteGroup", appId);
                await connection.stop();
            }
            stopPolling();
        });

        // 监听临时选择的多服务器站点数组，确保同一个 server.url 下只能单选一个站点
        watch(tempSelectedServerSites, (newVal) => {
            if (!Array.isArray(newVal) || newVal.length <= 1) return;

            // 用于记录每个 serverUrl 最后一次出现（或最后一次被勾选）的项
            const map = new Map();

            // 倒序遍历，保留用户最后勾选的那一项
            for (let i = newVal.length - 1; i >= 0; i--) {
                const item = newVal[i];
                if (item && item.serverUrl) {
                    // 如果这个 serverUrl 还没有被记录过，说明这是该服务器最新选中的项
                    if (!map.has(item.serverUrl)) {
                        map.set(item.serverUrl, item);
                    }
                }
            }

            // 将 Map 中的值重新组合成数组，并写回 tempSelectedServerSites
            const uniquePerServer = Array.from(map.values());

            // 只有当数量发生变化时才更新，防止死循环
            if (uniquePerServer.length !== newVal.length) {
                tempSelectedServerSites.value = uniquePerServer;
            }
        }, { deep: true });

        return {
            currentSiteItem,
            handleNodeSwitch,

            currentAppId,
            userPermission,
            hasPermission,
            pageName,
            siteStatus,
            createSiteDialogVisible,
            createSiteLoading,
            createSiteFormRef,
            createSiteForm,
            createSiteRules,
            submitCreateSite,
            showAddSiteDialog,
            deleteSite,
            deleteSiteLoading,
            serverIps,
            ipOptions,
            protocolOptions,
            loadDirectoryNodes,
            treeProps,
            popoverRef,
            inputRef,
            popoverWidth,
            updatePopoverWidth,
            handleSitePathClick,
            openEditSite,
            updateSiteType,

            openBindingDialog,
            iisBindDialog,
            iisBindFormRef,
            handleIISBindSubmit,
            addBindingRow,
            removeBindingRow,
            restartSite,
            openAddApplication,

            /////pool
            getAppPools,
            pollLoading,
            poolStartLoading,
            poolEndLoading,
            poolRecycleLoading,
            pollSearch,
            selectedPool,
            selectPool,
            startPool,
            stopPool,
            recyclePool,
            savePoolSettings,
            filteredPools,
            pools,
            createLoading,
            poolSaveLoading,
            deletePoolLoading,
            createDialogVisible,
            createForm,
            submitCreatePool,
            handleDeletePool,
            renameDialogVisible,
            poolRenameLoading,
            submitRenamePool,
            newPoolName,
            renameSiteDialogVisible,
            newSiteName,
            submitRenameSite,
            ///logs
            logDialogVisible,
            logLoading,
            logQuery,
            logData,
            showLogs,
            handleSearch,
            resetSearch,
            getDurationTagType,
            fetchLogs,
            ///user
            userLoading,
            userSearch,
            addUserDialog,
            userFormRef,
            submitUserLoading,
            userForm,
            userRules,
            handleUserSubmit,
            getUsers,
            filteredUsers,
            selectUser,
            selectedUser,
            enableUser,
            userMode,
            addUserDialogShow,
            handleUserEditShow,
            getSitePermissionSummary,
            hasShowSettings,
            hasShowCommonActions,
            getUserInitial,
            selectAllSystemPermissions,
            selectAllSitePermissions,
            selectAllSitePermission,
            selectAppPoolPermission,
            selectUserPermission,
            selectSitePermission,
            isAllSelected,
            getPermissionCount,
            saveUserPermission,
            deleteUser,
            resetUserPermission,
            //servers
            deploySiteListLoading,
            showSiteDeploySettingDialog,
            siteDeploySettingDialog,
            selectedServerSites,
            tempSelectedServerSites,
            serverList,
            saveSiteDeploySetting,
            isServerAllSelected,
            isServerIndeterminate,

            changePage,
            siteLoading,
            sites,
            startSite,
            stopSite,
            selectedSite,
            selectedApp,
            selectedFile,
            activeTab,
            backups,
            isRecently,
            changeRecently,
            selectedBackupId,
            backupBeforeDeploy,
            backupUploadFiles,
            stopBeforeDeploy,
            startEndDeploy,
            fileList,
            backupExcludeDirectories,
            backupExcludeExtensions,
            handleDrop,
            publishing,
            rollingBack,
            publishButtonText,
            collapsedNodes,
            formatDate,
            formatSize,
            treeData,
            hasChildren,
            folderInputRef,
            uploadRef,
            triggerFolderSelect,
            onFolderSelect,
            isExpanded,
            toggleNode,
            handleNodeClick,
            onFileChange,
            handleRemoveFile,
            isSingleZip,
            totalSelectedSize,
            loadBackups,
            loadingBackUp,
            publishSite,
            rollbackSite,
            deleteBackup,
            downloadBackup,
            refreshSites,
            selectedPhysicalPath,
            visible,
            form,
            login,
            rules,
            loginForm,
            messageHubs,
            totalSiteUsers,
            currentSiteUsers,
            zipDialogVisible,
            zipLoading,
            zipFileList,
            openZipPreview,
            formatLocalTime,
            logout,
            changeLan
        };
    }
});

app.use(ElementPlus);
function translate(key, ...args) {
    // 获取翻译模版（比如 "共 {0} 个可部署节点"）
    let template = window.I18N[key] || key;

    // 如果有参数，替换 {0}, {1} 等占位符
    if (args.length > 0) {
        return template.replace(/{(\d+)}/g, (match, index) => {
            return typeof args[index] !== 'undefined' ? args[index] : match;
        });
    }
    return template;
}
Object.assign(translate, window.I18N);
app.config.globalProperties.$i18n = translate;

app.mount('#app');

lucide.createIcons();
